# DAGO FF — prototype de départ

## Contenu
- `index.html` : maquette responsive pour Android, iPhone et ordinateur.
- Page d’accueil minimaliste : logo DAGO FF, bouton Inscription et choix de langue uniquement.
- Formulaire de démonstration d’inscription et de connexion dans des fenêtres.
- Langues : malagasy, français et anglais.

## Publier sur GitHub Pages
1. Dans le dépôt `dago-ff`, remplacez le fichier `index.html` existant par celui-ci.
2. Cliquez sur **Commit changes** pour enregistrer.
3. Ouvrez **Settings → Pages** et vérifiez que la source est `Deploy from a branch`, la branche `main` et le dossier `/ (root)`.
4. Le site sera généralement accessible à `https://thominot501-design.github.io/dago-ff/` après le déploiement.

## Important
Ceci est une maquette frontend, pas un système d'inscription réel. Le formulaire ne transmet ni ne sauvegarde les données. Google OAuth, OTP/SMS, profils réels, messagerie, administration, portefeuille et paiements nécessitent un backend sécurisé, une base de données et des services configurés. Ne mettez pas de mots de passe, clés secrètes ou codes OTP dans le code public.
